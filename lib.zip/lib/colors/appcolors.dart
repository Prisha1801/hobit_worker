import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

final Color kLightPink = HexColor('#FFF2FD');
final Color kkRed = HexColor('#D4E4FF');
final Color kGreen = HexColor('#52B46B');
final Color kGrey = HexColor('#D9DDDF80');
final Color kBlue = HexColor('#15253F');
final Color kCyan = HexColor('#00C0E8');
final Color kkblack = HexColor('#000000');
const Color kWhite = Colors.white;
const Color kBlack = Colors.black;
