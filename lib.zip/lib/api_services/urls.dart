//const String baseUrl = "https://hobitadmin.anantkamalsoftwarelabs.com";
const String baseUrl = "https://backendhobit.anantkamalsoftwarelabs.com";
//registrations apis
const String signUpUrl = "/api/worker/register_app";
const String  serviceCategoriesUrl = "/api/service-categories";
const String  serviceUrl = "/api/services";
const String  citiesUrl = "/api/cities";
const String  zonesUrl = "/api/zones";
const String  serviceAreaUrl = "/api/serviceable-areas";
/// login
const String  loginUrl = "/api/worker/login/send-otp";
const String  verifyOtpUrl = "/api/worker/login/verify-otp";
const String logoutUrl = "/api/logout";
const String getBankDetailsUrl = "/api/worker/bank-details";
const String putBankDetailsUrl = "/api/worker/update_bank_details";
const String getPersonalInfoUrl = "/api/worker/me";



