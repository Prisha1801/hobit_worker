class PreferencesKey {
  static String userId = "userId";
  static String name = "name";
  static  String phone = 'phone';
  static  String token = 'token';
  static  String isLoggedIn = 'is_logged_in';
}