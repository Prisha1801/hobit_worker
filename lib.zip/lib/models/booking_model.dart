class AssignedBookingModel {
  final int id;
  final String customerName;
  final String customerPhone;
  final String bookingDate;
  final String timeSlot;
  final String address;
  final String city;
  final String status;
  final ServiceModel service;

  AssignedBookingModel({
    required this.id,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
    required this.timeSlot,
    required this.address,
    required this.city,
    required this.status,
    required this.service,
  });

  factory AssignedBookingModel.fromJson(Map<String, dynamic> json) {
    return AssignedBookingModel(
      id: json['id'],
      customerName: json['customer_name'] ?? '',
      customerPhone: json['customer_phone'] ?? '',
      bookingDate: json['booking_date'] ?? '',
      timeSlot: json['time_slot'] ?? '',
      address: json['address'] ?? '',
      city: json['city'] ?? '',
      status: json['status'] ?? '',
      service: ServiceModel.fromJson(json['service']),
    );
  }
}

class ServiceModel {
  final int id;
  final String name;
  final String description;
  final String price;

  ServiceModel({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
  });

  factory ServiceModel.fromJson(Map<String, dynamic> json) {
    return ServiceModel(
      id: json['id'],
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      price: json['price'] ?? '0',
    );
  }
}
